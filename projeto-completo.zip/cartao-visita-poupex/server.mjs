import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { timingSafeEqual } from 'node:crypto';
import { walletAvailability, createApplePass, createGooglePass } from './lib/wallet.mjs';
const C = globalThis.PoupexContact;
const root = fileURLToPath(new URL('./public/', import.meta.url));
const host = process.env.HOST || '127.0.0.1', port = Number(process.env.PORT || 4173);
const origin = new URL(process.env.APP_BASE_URL || `http://localhost:${port}`).origin;
const production = process.env.NODE_ENV === 'production';
if (production && (!origin.startsWith('https://') || !process.env.APP_USERNAME || (process.env.APP_PASSWORD || '').length < 16)) throw new Error('Produção exige APP_BASE_URL com HTTPS, APP_USERNAME e APP_PASSWORD com pelo menos 16 caracteres.');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.png': 'image/png', '.md': 'text/plain; charset=utf-8' };
const securityHeaders = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'X-Frame-Options': 'DENY', 'Permissions-Policy': 'camera=(), microphone=(), geolocation=()', 'Cache-Control': 'no-store', 'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'" };
const send = (res, status, data, headers = {}) => { res.writeHead(status, { ...securityHeaders, ...headers }); res.end(data); };
const json = (res, status, data, headers) => send(res, status, JSON.stringify(data), { 'Content-Type': 'application/json; charset=utf-8', ...headers });
const buckets = new Map();
function rateLimited(ip) {
  const now = Date.now();
  if (buckets.size > 1000) for (const [key, entry] of buckets) if (entry.until < now) buckets.delete(key);
  let entry = buckets.get(ip); if (!entry || entry.until < now) { entry = { count: 0, until: now+60000 }; buckets.set(ip, entry); }
  return ++entry.count > 15;
}
function authorized(req) {
  if (!process.env.APP_USERNAME || !process.env.APP_PASSWORD) return true;
  const expected = Buffer.from('Basic ' + Buffer.from(process.env.APP_USERNAME + ':' + process.env.APP_PASSWORD).toString('base64'));
  const actual = Buffer.from(req.headers.authorization || ''); return actual.length === expected.length && timingSafeEqual(actual, expected);
}
async function body(req) {
  const chunks = []; let bytes = 0;
  for await (const chunk of req) { bytes += chunk.length; if (bytes > 8192) throw Object.assign(new Error('O formulário excedeu o tamanho permitido.'), { status: 413 }); chunks.push(chunk); }
  try { const data = JSON.parse(Buffer.concat(chunks).toString('utf8')); if (!data || Array.isArray(data) || typeof data !== 'object') throw 0; return data; }
  catch { throw Object.assign(new Error('Envie um formulário válido.'), { status: 400 }); }
}
const server = http.createServer(async (req, res) => {
  try {
    if (!authorized(req)) return send(res, 401, 'Acesso institucional necessário.', { 'WWW-Authenticate': 'Basic realm="Cartao FHE POUPEX", charset="UTF-8"' });
    const url = new URL(req.url, origin);
    if (req.method === 'GET' && url.pathname === '/api/config') return json(res, 200, walletAvailability());
    if (url.pathname.startsWith('/api/wallet/')) {
      if (req.method !== 'POST') return json(res, 405, { error: 'Use o formulário para emitir um cartão.' }, { Allow: 'POST' });
      if (req.headers.origin !== origin) return json(res, 403, { error: 'Abra o formulário no endereço oficial do sistema.' });
      if (!req.headers['content-type']?.startsWith('application/json')) return json(res, 415, { error: 'Envie o formulário no formato esperado.' });
      if (rateLimited(req.socket.remoteAddress)) return json(res, 429, { error: 'Muitas solicitações. Aguarde um minuto e tente novamente.' }, { 'Retry-After': '60' });
      const kind = url.pathname.slice('/api/wallet/'.length);
      if (!['apple', 'google'].includes(kind)) return json(res, 404, { error: 'Carteira não encontrada.' });
      const result = C.validate(await body(req)); if (!result.valid) return json(res, 422, { error: 'Confira os dados do cartão.', fields: result.errors });
      if (!walletAvailability()[kind]) return json(res, 503, { error: 'A emissão nesta carteira aguarda a configuração institucional.' });
      try {
        if (kind === 'apple') return send(res, 200, await createApplePass(result.data), { 'Content-Type': 'application/vnd.apple.pkpass', 'Content-Disposition': `attachment; filename="${C.filename(result.data.name)}.pkpass"` });
        return json(res, 200, { url: await createGooglePass(result.data, origin) });
      } catch { return json(res, 502, { error: 'Não foi possível emitir o cartão. Solicite a conferência da conta de emissão e dos certificados.' }); }
    }
    if (url.pathname.startsWith('/api/')) return json(res, 404, { error: 'Endereço não encontrado.' });
    if (!['GET', 'HEAD'].includes(req.method)) return send(res, 405, 'Método não permitido.', { Allow: 'GET, HEAD' });
    const pathname = decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname), filename = path.resolve(root, '.' + pathname);
    if (!filename.startsWith(root) || pathname.split('/').some(part => part.startsWith('.')) || !types[path.extname(filename)]) return send(res, 404, 'Arquivo não encontrado.');
    try { if (!(await stat(filename)).isFile()) throw 0; const content = await readFile(filename); return send(res, 200, req.method === 'HEAD' ? undefined : content, { 'Content-Type': types[path.extname(filename)], 'Content-Length': content.length }); }
    catch { return send(res, 404, 'Arquivo não encontrado.'); }
  } catch (error) { json(res, error.status || 400, { error: error.status ? error.message : 'Não foi possível processar a solicitação.' }); }
});
server.requestTimeout = 30000; server.headersTimeout = 15000;
server.listen(port, host, () => console.log(`Cartão FHE POUPEX disponível em ${origin}`));
process.on('SIGTERM', () => server.close());
process.on('SIGINT', () => server.close());
