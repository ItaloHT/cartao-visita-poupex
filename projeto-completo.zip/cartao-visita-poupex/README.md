# Cartão de visita · FHE POUPEX

Evolução do estudo de layout original de `ItaloHT/cartao-visita-poupex`, preparada em 26/11/2026. Usa o fundo texturizado, a assinatura FHE POUPEX e as três setas fornecidos pelo usuário, com nome abaixo da marca e QR Code na base. A imagem da Apple Wallet enviada é uma referência visual; cada carteira controla sua própria composição.

## O que já funciona

- Formulário responsivo com prévia, validação e normalização de telefones brasileiros e internacionais.
- QR Code com vCard 3.0, gerado localmente, com acentos e escape de caracteres.
- Download de contato `.vcf` para a agenda.
- PDF de 90 × 126 mm, com cartão renderizado em 1500 × 2100 pixels e QR Code, sem serviço externo. O conteúdo do PDF é uma imagem; não há texto selecionável nem marcação de acessibilidade no PDF.
- Interface acessível por teclado, mensagens de validação, aviso para carteiras pendentes e exemplo com dados fictícios.
- Servidor para gerar `.pkpass` assinado e link de adição ao Google Wallet quando as credenciais institucionais forem configuradas.

Não foram fornecidas credenciais Apple ou Google. A instalação dos passes em dispositivos reais permanece pendente de configuração e homologação institucional. Os botões mostram “Em preparação” até as credenciais estarem presentes; a presença dos arquivos não comprova validade dos certificados ou autorização de produção.

## Executar o projeto

Requisitos: Node.js 22.9 ou superior. Não há pacotes a instalar. A emissão Apple também exige OpenSSL instalado e disponível no servidor.

```sh
cp .env.example .env
npm start
```

Abra `http://localhost:4173`. Alternativamente, execute `node --env-file-if-exists=.env server.mjs`.

```sh
npm test
```

Os testes verificam regras de contato, limites do QR Code, modelos das carteiras, assinatura JWT, pacote ZIP e respostas HTTP. As chamadas reais ao Google e a instalação na Apple Wallet exigem credenciais e não fazem parte desses testes.

## O que solicitar à equipe responsável

### Apple Wallet

Solicitar ao responsável pela conta Apple Developer institucional:

1. Confirmação de participação no Apple Developer Program e do Team ID.
2. Um Pass Type ID para este cartão e certificado Pass Type ID correspondente.
3. Certificado e chave privada em PEM, além do certificado intermediário Apple WWDR correto para o certificado de assinatura. Quando aplicável, senha da chave privada.
4. Configuração segura desses materiais diretamente no servidor; nunca no GitHub, no formulário ou em mensagens de chat.

Configurar `APPLE_TEAM_ID`, `APPLE_PASS_TYPE_ID`, `APPLE_CERT_FILE`, `APPLE_KEY_FILE`, `APPLE_WWDR_FILE` e, se necessário, `APPLE_KEY_PASSWORD` e `OPENSSL_BIN` em `.env`. Os caminhos podem ser absolutos e devem apontar para arquivos fora de `public/`.

A implementação gera `pass.json`, imagens, manifesto SHA-1 e assinatura PKCS#7 destacada e os empacota em `.pkpass`. Não inclui atualização automática, notificações push ou revogação de cartões já instalados. Cada combinação de dados recebe um identificador próprio; alterar dados emite outro cartão.

Referências: [começar com Apple Wallet](https://developer.apple.com/wallet/get-started/), [identificadores e certificados](https://developer.apple.com/help/account/capabilities/create-wallet-identifiers-and-certificates/), [construção de passes](https://developer.apple.com/documentation/walletpasses/building-a-pass).

### Google Wallet

Solicitar ao responsável por Google Cloud / Google Wallet:

1. Conta de emissor Google Wallet institucional e seu Issuer ID.
2. API Google Wallet habilitada no Google Cloud.
3. Conta de serviço adicionada com acesso Developer no console Google Pay & Wallet; credencial JSON configurada diretamente no servidor.
4. Logo em PNG hospedado publicamente por HTTPS, sem login, em URL institucional estável.
5. Contas de teste autorizadas e aprovação para publicação antes da distribuição a todos os funcionários.

Configurar `GOOGLE_ISSUER_ID`, `GOOGLE_SERVICE_ACCOUNT_FILE`, `GOOGLE_LOGO_URL` e, opcionalmente, `GOOGLE_CLASS_SUFFIX`. A conta de serviço precisa poder consultar/criar classes e objetos. O servidor cria os recursos pela API e assina um JWT curto que referencia o objeto já criado, evitando um link extenso com todos os dados do contato. O link é emitido com validade de uma hora.

Referências: [conta de emissor](https://developers.google.com/wallet/generic/getting-started/issuer-onboarding), [credenciais](https://developers.google.com/wallet/generic/getting-started/auth/rest), [emissão web](https://developers.google.com/wallet/generic/web), [JWT](https://developers.google.com/wallet/generic/use-cases/jwt).

## Publicação institucional

A publicação no GitHub Pages usa a versão estática gerada com `npm run build:pages`. Ela oferece formulário, prévia, QR Code, PDF e contato; a emissão nas carteiras exige o servidor configurado separadamente. O resultado fica em `dist/index.html`.

O servidor usa `127.0.0.1` por padrão. Para produção, a TI deve colocar o serviço atrás de proxy HTTPS, ajustar `APP_BASE_URL` para a origem oficial e definir `NODE_ENV=production`, `APP_USERNAME` e `APP_PASSWORD` com ao menos 16 caracteres. O processo recusa inicialização em produção sem esses parâmetros. A autenticação incluída é HTTP Basic; login individual, SSO, autorização por funcionário e fluxo de aprovação editorial ainda não foram implementados e devem ser definidos antes do uso por uma equipe. Quem tiver o acesso configurado pode emitir cartões com os campos que preencher; não existe verificação automática de vínculo funcional.

O serviço não armazena um cadastro de funcionários e não registra dados de contato em logs. Os dados são enviados à carteira somente quando o usuário pede essa emissão. Proteger as chaves com um gerenciador de segredos, manter certificados válidos e configurar restrições de acesso no ambiente institucional. O limite de solicitações é por endereço de conexão; atrás de um proxy ele é compartilhado. Para uso em escala, a TI deverá ajustar o limite na borda e a gestão de acesso.

Antes da liberação: testar em iPhone e Android reais, conferir as duas marcas e legibilidade dos campos, escanear o QR Code com outro aparelho e homologar a política de emissão. A aparência nas carteiras será a que cada plataforma suportar, sem garantia de reprodução exata da imagem de referência.

## Organização e atribuições

- `public/`: interface, regras de contato, marca original e bibliotecas locais.
- `lib/`: assinatura e modelos de carteiras, criação do arquivo ZIP.
- `wallet-assets/`: versões da marca dimensionadas para o passe Apple.
- `test/`: testes automatizados.
- `.env.example`: nomes das configurações, sem segredos.
- `referencia/index-original.html`: arquivo original, preservado para comparação.

A biblioteca de QR Code foi preservada do arquivo original, incluindo seus avisos Apache 2.0 / MIT. `pdf-lib` é distribuído sob MIT, com licença em `public/vendor/pdf-lib.LICENSE.md`. As marcas permanecem de seus respectivos titulares. Esta entrega altera o projeto original e não representa uma homologação institucional.
