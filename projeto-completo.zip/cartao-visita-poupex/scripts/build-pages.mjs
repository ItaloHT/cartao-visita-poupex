// Build the self-contained GitHub Pages version without publishing secrets or a server.
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
const root = fileURLToPath(new URL('../public/', import.meta.url));
const destination = process.argv[2] || fileURLToPath(new URL('../dist/index.html', import.meta.url));
const images = [
  ['assets/marca-fhe-poupex.png', 'image/png'],
  ['assets/fundo-cartao.jpg', 'image/jpeg'],
  ['assets/setas-institucionais.png', 'image/png'],
  ['assets/wallet-apple.png', 'image/png'],
  ['assets/wallet-google.png', 'image/png']
];
const urls = [];
for (const [name, mime] of images) urls.push([name, `data:${mime};base64,${(await readFile(path.join(root, name))).toString('base64')}`]);
const embed = value => urls.reduce((text, [name, data]) => text.replaceAll(name, data), value);
let html = await readFile(path.join(root, 'index.html'), 'utf8');
html = html.replace('<html lang="pt-BR">', '<html lang="pt-BR" data-standalone="true">');
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>' + embed(await readFile(path.join(root, 'styles.css'), 'utf8')) + '</style>');
const scripts = [];
for (const name of ['vendor/qr.js', 'vendor/pdf-lib.min.js', 'contact.js', 'app.js']) {
  html = html.replace(`<script src="${name}" defer></script>`, '');
  scripts.push('<script>' + embed(await readFile(path.join(root, name), 'utf8')).replaceAll('</script', '<\\/script') + '</script>');
}
html = embed(html).replace('</body>', scripts.join('\n') + '\n</body>');
await mkdir(path.dirname(destination), { recursive: true });
await writeFile(destination, html);
console.log('Página estática preparada em ' + destination);
