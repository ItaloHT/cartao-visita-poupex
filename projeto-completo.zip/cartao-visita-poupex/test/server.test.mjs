import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
const origin = 'http://localhost:4189'; let child;
before(async () => {
  const env = { ...process.env, HOST: '127.0.0.1', PORT: '4189', APP_BASE_URL: origin, NODE_ENV: 'development', APP_USERNAME: '', APP_PASSWORD: '', APPLE_TEAM_ID: '', GOOGLE_ISSUER_ID: '' };
  child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('..', import.meta.url), env, stdio: ['ignore','pipe','pipe'] });
  await Promise.race([once(child.stdout, 'data'), once(child, 'exit').then(() => { throw new Error('Servidor de teste não iniciou.'); })]);
});
after(() => { child?.kill(); });
const contact = { name: 'Marina Costa', job: 'Analista', unit: 'CECOM', email: 'marina@example.org', phone: '(61) 99999-0000' };
const post = (data, headers = {}) => fetch(origin + '/api/wallet/apple', { method:'POST', headers: { 'Content-Type':'application/json', Origin:origin, ...headers }, body:JSON.stringify(data) });
test('serve a interface e dependências locais, com cabeçalhos de proteção', async () => {
  const response = await fetch(origin); assert.equal(response.status,200); assert.match(await response.text(),/Crie seu cartão/); assert.equal(response.headers.get('x-content-type-options'),'nosniff');
  for (const url of ['/app.js','/contact.js','/vendor/qr.js','/vendor/pdf-lib.min.js','/assets/marca-fhe-poupex.png']) assert.equal((await fetch(origin+url)).status,200);
});
test('não serve configurações, arquivos internos nem chaves', async () => {
  for (const url of ['/.env','/server.mjs','/lib/wallet.mjs','/wallet-assets/icon.png','/%2e%2e%2fserver.mjs','/vendor/../../package.json']) assert.equal((await fetch(origin+url)).status,404);
});
test('informa carteiras pendentes e recusa emissão sem certificado', async () => {
  assert.deepEqual(await (await fetch(origin+'/api/config')).json(),{apple:false,google:false});
  const response = await post(contact); assert.equal(response.status,503); assert.match((await response.json()).error,/configuração institucional/);
});
test('valida dados no servidor e recusa origens externas', async () => {
  assert.equal((await post({...contact,email:'inválido'})).status,422);
  assert.equal((await post(contact,{Origin:'https://outro.example'})).status,403);
  assert.equal((await post(contact,{'Content-Type':'text/plain'})).status,415);
  const response = await fetch(origin+'/api/wallet/apple'); assert.equal(response.status,405);
});
