import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash, generateKeyPairSync } from 'node:crypto';
import { createApplePass, createGooglePass } from '../lib/wallet.mjs';
const exec = promisify(execFile);
const contact = { name: 'João Gonçalves', job: 'Especialista', unit: 'CECOM', email: 'joao@example.org', phone: '+5561981250000' };
function unzipStored(bytes) {
  const files = {}; let offset = 0;
  while (bytes.readUInt32LE(offset) === 0x04034b50) {
    const size = bytes.readUInt32LE(offset+18), nameLength = bytes.readUInt16LE(offset+26), extra = bytes.readUInt16LE(offset+28);
    const name = bytes.subarray(offset+30,offset+30+nameLength).toString();
    const begin = offset+30+nameLength+extra; files[name] = bytes.subarray(begin,begin+size); offset = begin+size;
  } return files;
}
test('pacote Apple contém manifesto íntegro e assinatura PKCS#7 verificável com certificado de teste', async t => {
  try { await exec('openssl',['version']); } catch { t.skip('OpenSSL não instalado neste ambiente.'); return; }
  const dir = await mkdtemp(path.join(tmpdir(),'poupex-wallet-test-')), saved = {...process.env};
  try {
    const key = path.join(dir,'key.pem'), cert = path.join(dir,'cert.pem');
    await exec('openssl',['req','-x509','-newkey','rsa:2048','-nodes','-keyout',key,'-out',cert,'-days','1','-subj','/CN=POUPEX TEST ONLY']);
    Object.assign(process.env,{APPLE_TEAM_ID:'TESTONLY',APPLE_PASS_TYPE_ID:'pass.example.test',APPLE_CERT_FILE:cert,APPLE_KEY_FILE:key,APPLE_WWDR_FILE:cert,APPLE_KEY_PASSWORD:''});
    const files = unzipStored(await createApplePass(contact)), manifest = JSON.parse(files['manifest.json']);
    for (const [name,hash] of Object.entries(manifest)) assert.equal(createHash('sha1').update(files[name]).digest('hex'),hash);
    assert.equal(JSON.parse(files['pass.json']).generic.primaryFields[0].value,contact.name);
    assert.ok(files['icon@3x.png']); assert.ok(files['logo@2x.png']);
    const sig = path.join(dir,'signature'), content = path.join(dir,'manifest.json'); await writeFile(sig,files.signature); await writeFile(content,files['manifest.json']);
    const verified = await exec('openssl',['smime','-verify','-binary','-inform','DER','-in',sig,'-content',content,'-noverify']);
    assert.deepEqual(JSON.parse(verified.stdout),manifest);
  } finally { for (const key of Object.keys(process.env)) if (!(key in saved)) delete process.env[key]; Object.assign(process.env,saved); await rm(dir,{recursive:true,force:true}); }
});
test('fluxo Google cria classe e objeto e emite JWT curto, com API simulada', async () => {
  const dir = await mkdtemp(path.join(tmpdir(),'poupex-google-test-')), saved = {...process.env}, originalFetch = globalThis.fetch, calls = [];
  try {
    const {privateKey} = generateKeyPairSync('rsa',{modulusLength:2048}), file = path.join(dir,'account.json');
    await writeFile(file,JSON.stringify({client_email:'test@example.iam.gserviceaccount.com',private_key:privateKey.export({type:'pkcs8',format:'pem'})}));
    Object.assign(process.env,{GOOGLE_ISSUER_ID:'123456',GOOGLE_LOGO_URL:'https://example.org/logo.png',GOOGLE_SERVICE_ACCOUNT_FILE:file});
    globalThis.fetch = async (url, options={}) => {
      calls.push({url,options});
      if (url === 'https://oauth2.googleapis.com/token') return Response.json({access_token:'TEST_ONLY',expires_in:3600});
      if (!options.method) return new Response('',{status:404});
      return Response.json(JSON.parse(options.body));
    };
    const url = await createGooglePass(contact,'https://cartao.example.org'); assert.ok(url.length<1800);
    const jwt = url.split('/').at(-1), payload=JSON.parse(Buffer.from(jwt.split('.')[1],'base64url'));
    assert.deepEqual(payload.origins,['https://cartao.example.org']); assert.equal(payload.typ,'savetowallet');
    assert.ok(payload.payload.genericObjects[0].id.startsWith('123456.'));
    const objectCall = calls.find(c=>c.url.endsWith('/genericObject') && c.options.method==='POST');
    assert.equal(JSON.parse(objectCall.options.body).header.defaultValue.value,contact.name);
    assert.ok(!url.includes(contact.email));
  } finally { globalThis.fetch=originalFetch; for (const key of Object.keys(process.env)) if (!(key in saved)) delete process.env[key]; Object.assign(process.env,saved); await rm(dir,{recursive:true,force:true}); }
});
