import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { createVerify, generateKeyPairSync } from 'node:crypto';
import '../public/contact.js';
import { applePass, googleObject, signJWT, walletAvailability } from '../lib/wallet.mjs';
import { zip } from '../lib/zip.mjs';
const C = globalThis.PoupexContact;
const contact = { name: 'João Gonçalves', job: 'Especialista em Comunicação', unit: 'CECOM', email: 'joao@example.org', phone: '(61) 98125-0000' };
test('normaliza telefones sem duplicar +55 e mantém números internacionais', () => {
  assert.equal(C.validate(contact).data.phone, '+5561981250000');
  assert.equal(C.normalize({ phone: '+55 (61) 98125-0000' }).phone, '+5561981250000');
  assert.equal(C.normalize({ phone: '5561981250000' }).phone, '+5561981250000');
  assert.equal(C.normalize({ phone: '+351 912 345 678' }).phone, '+351912345678');
  assert.equal(C.displayPhone('+5561981250000'), '+55 (61) 98125-0000');
});
test('recusa formulário incompleto, injeção de linhas e campos fora dos limites', () => {
  assert.equal(C.validate(contact).valid, true); assert.equal(C.validate({}).valid, false);
  assert.equal(C.validate({ ...contact, name: 'João\nURL:malicioso' }).valid, false);
  assert.equal(C.validate({ ...contact, email: 'joao@' }).valid, false);
  assert.equal(C.validate({ ...contact, phone: 'ligue 61981250000' }).valid, false);
  assert.equal(C.validate({ ...contact, unit: 'a'.repeat(61) }).valid, false);
});
test('vCard preserva acentos, escapa separadores e dobra linhas UTF-8 sem corromper caracteres', () => {
  const card = C.vcard({ ...contact, name: 'João; Silva, Júnior', job: 'Comunicação '.repeat(10) });
  assert.ok(card.includes('FN:João\\; Silva\\, Júnior\r\n'));
  for (const line of card.split('\r\n')) assert.ok(Buffer.byteLength(line) <= 75);
  assert.ok(card.endsWith('END:VCARD\r\n')); assert.ok(!card.includes('\ufffd'));
});
test('QR comporta o formulário completo nos limites permitidos', () => {
  const scope = { TextEncoder }; scope.globalThis = scope;
  vm.runInNewContext(readFileSync(new URL('../public/vendor/qr.js', import.meta.url), 'utf8'), scope);
  const max = { name: 'Á'.repeat(80), job: 'Ç'.repeat(80), unit: 'Ó'.repeat(60), email: 'a'.repeat(108) + '@example.org', phone: '+5561981250000' };
  const qr = new scope.PoupexQR(-1, 0); qr.addData(String.fromCharCode(...new TextEncoder().encode(C.vcard(max)))); qr.make();
  assert.ok(qr.getModuleCount() >= 21); assert.ok(qr.getModuleCount() <= 177);
});
test('modelos Apple e Google usam os mesmos dados e IDs estáveis sem expor e-mail no identificador', () => {
  const data = C.normalize(contact), config = { APPLE_PASS_TYPE_ID: 'pass.example.business', APPLE_TEAM_ID: 'TEAM123', GOOGLE_ISSUER_ID: '1234', GOOGLE_LOGO_URL: 'https://example.org/logo.png' };
  const apple = applePass(data, config), google = googleObject(data, config);
  assert.equal(apple.barcodes[0].message, C.vcard(data)); assert.equal(google.barcode.value, C.vcard(data));
  assert.equal(apple.generic.primaryFields[0].value, contact.name); assert.equal(google.header.defaultValue.value, contact.name);
  assert.equal(apple.serialNumber, applePass(data, config).serialNumber); assert.ok(!google.id.includes('@'));
});
test('assinatura JWT RS256 é verificável e mantém acentos', () => {
  const { privateKey, publicKey } = generateKeyPairSync('rsa', { modulusLength: 2048 });
  const jwt = signJWT({ name: contact.name }, privateKey), parts = jwt.split('.');
  const verifier = createVerify('RSA-SHA256'); verifier.update(parts.slice(0,2).join('.')); verifier.end();
  assert.equal(verifier.verify(publicKey, Buffer.from(parts[2], 'base64url')), true);
  assert.equal(JSON.parse(Buffer.from(parts[1], 'base64url')).name, contact.name);
});
test('ZIP tem cabeçalho, diretório e conteúdo preservado', () => {
  const archive = zip({ 'pass.json': '{"name":"João"}', signature: Buffer.from([1,2,3]) });
  assert.equal(archive.readUInt32LE(0), 0x04034b50); assert.equal(archive.readUInt32LE(archive.length-22), 0x06054b50);
  assert.equal(archive.readUInt16LE(archive.length-14), 2); assert.ok(archive.includes(Buffer.from('João')));
});
test('carteiras permanecem indisponíveis sem credenciais', () => {
  assert.deepEqual(walletAvailability(), { apple: false, google: false });
});
