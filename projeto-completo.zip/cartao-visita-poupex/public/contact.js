/* Shared contact rules, modified for FHE POUPEX, November 2026. */
(() => {
  const limits = { name: 80, job: 80, unit: 60, email: 120, phone: 30 };
  function normalize(raw) {
    const data = {};
    for (const key of Object.keys(limits)) data[key] = String(raw[key] ?? '').normalize('NFC').trim();
    data.email = data.email.toLowerCase();
    const digits = data.phone.replace(/\D/g, '');
    if (!data.phone.startsWith('+') && /^(\d{10}|\d{11})$/.test(digits)) data.phone = '+55' + digits;
    else if (digits) data.phone = '+' + digits;
    return data;
  }
  function validate(raw) {
    const data = normalize(raw), errors = {};
    for (const [key, max] of Object.entries(limits)) {
      if (typeof raw[key] !== 'string' && raw[key] != null) errors[key] = 'Informe um texto válido.';
      else if (String(raw[key] ?? '').length > max) errors[key] = `Use no máximo ${max} caracteres.`;
      else if (/[\x00-\x1f\x7f]/.test(String(raw[key] ?? ''))) errors[key] = 'Remova quebras de linha ou caracteres de controle.';
    }
    for (const key of ['name', 'job', 'email', 'phone']) if (!data[key]) errors[key] = 'Preencha este campo.';
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) errors.email = 'Informe um e-mail válido.';
    const digits = data.phone.replace(/\D/g, '');
    if (data.phone && (!/^\+\d{10,15}$/.test(data.phone) || /^\+55/.test(data.phone) && !/^(\d{12}|\d{13})$/.test(digits))) errors.phone = 'Confira o DDD e o telefone. Para outros países, use + e o código do país.';
    if (String(raw.phone ?? '').trim() && !/^[+\d\s().-]+$/.test(String(raw.phone))) errors.phone = 'Use apenas números, espaços e os sinais + ( ) - .';
    return { data, errors, valid: Object.keys(errors).length === 0 };
  }
  const escape = value => String(value).replace(/\\/g, '\\\\').replace(/\r\n|\r|\n/g, '\\n').replace(/;/g, '\\;').replace(/,/g, '\\,');
  function fold(line) {
    const encoder = new TextEncoder(); let result = '', count = 0;
    for (const char of line) { const size = encoder.encode(char).length; if (count + size > 75) { result += '\r\n '; count = 1; } result += char; count += size; }
    return result;
  }
  function vcard(raw) {
    const c = normalize(raw);
    return ['BEGIN:VCARD', 'VERSION:3.0', 'FN:' + escape(c.name), 'N:;' + escape(c.name) + ';;;', 'ORG:FHE POUPEX;' + escape(c.unit), 'TITLE:' + escape(c.job), 'EMAIL;TYPE=INTERNET,WORK:' + escape(c.email), 'TEL;TYPE=CELL,WORK:' + c.phone, 'URL:https://www.poupex.com.br', 'END:VCARD'].map(fold).join('\r\n') + '\r\n';
  }
  function displayPhone(value) {
    const phone = normalize({phone:value}).phone;
    if (/^\+55\d{10,11}$/.test(phone)) { const d = phone.slice(3); return `+55 (${d.slice(0, 2)}) ${d.slice(2, -4)}-${d.slice(-4)}`; }
    return phone;
  }
  function filename(name) { return 'cartao-' + (String(name).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0,60) || 'poupex'); }
  globalThis.PoupexContact = Object.freeze({ limits, normalize, validate, vcard, displayPhone, filename });
})();
