/* Interface aprimorada para FHE POUPEX, novembro de 2026. */
(() => {
  const C = PoupexContact, $ = id => document.getElementById(id);
  const keys = Object.keys(C.limits), touched = new Set();
  let walletConfig = { apple: false, google: false }, activeQR = '', timer;
  const raw = () => Object.fromEntries(keys.map(key => [key, $(key).value]));
  const feedback = (text, error = false) => { $('feedback').textContent = text; $('feedback').classList.toggle('error', error); };
  const showErrors = errors => keys.forEach(key => { const error = touched.has(key) ? errors[key] : ''; $(key + '-error').textContent = error || ''; $(key).setAttribute('aria-invalid', String(Boolean(error))); });
  function qrImage(contact) {
    const code = new PoupexQR(-1, 0);
    code.addData(String.fromCharCode(...new TextEncoder().encode(C.vcard(contact)))); code.make();
    const n = code.getModuleCount(), paths = [];
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (code.isDark(y, x)) paths.push(`M${x+4} ${y+4}h1v1h-1z`);
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n+8} ${n+8}" shape-rendering="crispEdges"><rect width="100%" height="100%" fill="white"/><path d="${paths.join('')}" fill="black"/></svg>`);
  }
  function update() {
    const result = C.validate(raw()), { data, errors, valid } = result;
    $('preview-name').textContent = (data.name || 'Seu nome').toLocaleUpperCase('pt-BR');
    $('preview-role').textContent = data.job ? data.job + (data.unit ? ' | ' + data.unit : '') : 'Seu cargo';
    $('preview-email').textContent = data.email || 'seu.nome@poupex.com.br';
    $('preview-phone').textContent = data.phone ? C.displayPhone(data.phone) : '+55 (61) 99999-9999';
    fitPreview();
    showErrors(errors);
    activeQR = ''; $('qr').hidden = true; $('qr-placeholder').hidden = false;
    if (valid) {
      try { activeQR = qrImage(data); $('qr').src = activeQR; $('qr').hidden = false; $('qr-placeholder').hidden = true; }
      catch { feedback('Os dados ficaram longos demais para o QR Code. Reduza os campos.', true); }
    }
    return { ...result, valid: valid && Boolean(activeQR) };
  }
  function ready() {
    keys.forEach(key => touched.add(key)); const result = update();
    if (!result.valid) { feedback('Confira os campos indicados para gerar seu cartão.', true); const invalid = keys.find(key => result.errors[key]); if (invalid) $(invalid).focus(); return null; }
    return result.data;
  }
  function download(blob, name) {
    const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = name; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  function loadImage(src) { return new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = reject; img.src = src; }); }
  function wrap(ctx, value, width) {
    const lines = []; let line = '';
    for (const word of value.split(/\s+/)) {
      const next = line ? line + ' ' + word : word;
      if (ctx.measureText(next).width <= width) { line = next; continue; }
      if (line) { lines.push(line); line = ''; }
      for (const char of word) { if (line && ctx.measureText(line + char).width > width) { lines.push(line); line = ''; } line += char; }
    }
    if (line) lines.push(line); return lines;
  }
  function fitPreview() {
    const card = document.querySelector('.business-card'), canvas = document.createElement('canvas'), ctx = canvas.getContext('2d');
    const width = card.clientWidth;
    for (const [id, ratio, weight] of [['preview-name', .056, 700], ['preview-role', .048, 400], ['preview-email', .048, 400], ['preview-phone', .048, 400]]) {
      const element = $(id), room = id === 'preview-email' || id === 'preview-phone' ? element.parentElement.clientHeight - width * .049 : element.clientHeight;
      let size = width * ratio;
      while (size > 6) {
        ctx.font = `${weight} ${size}px Arial, sans-serif`;
        const lines = wrap(ctx, element.textContent, element.clientWidth);
        if (lines.length * size * 1.13 <= room + .5) break;
        size -= .25;
      }
      element.style.fontSize = size + 'px';
    }
  }
  async function cardCanvas(c) {
    const [background, logo, motif, qr] = await Promise.all([loadImage('assets/fundo-cartao.jpg'), loadImage('assets/marca-fhe-poupex.png'), loadImage('assets/setas-institucionais.png'), loadImage(activeQR)]);
    const canvas = document.createElement('canvas'); canvas.width = 1500; canvas.height = 2100;
    const ctx = canvas.getContext('2d'); ctx.scale(3, 3);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, 500, 700);
    ctx.save(); ctx.beginPath(); ctx.roundRect(0, 0, 500, 700, 16); ctx.clip();
    ctx.drawImage(background, 0, 0, 500, 700);
    ctx.fillStyle = '#ffffff'; ctx.beginPath(); ctx.ellipse(250, 0, 42.5, 17, 0, 0, Math.PI); ctx.fill();
    ctx.drawImage(logo, 18, 39.2, 215, 215 * logo.height / logo.width);
    ctx.fillStyle = '#ffffff'; ctx.textBaseline = 'top';
    const drawText = (value, x, y, width, height, baseSize, weight = 400, color = '#ffffff') => {
      let size = baseSize, lines;
      while (size >= 7) {
        ctx.font = `${weight} ${size}px Arial, sans-serif`; lines = wrap(ctx, value, width);
        if (lines.length * size * 1.13 <= height) break;
        size -= .25;
      }
      if (size < 7) throw new Error('Reduza os textos para manter a legibilidade do cartão.');
      ctx.fillStyle = color;
      lines.forEach((line, i) => ctx.fillText(line, x, y + i * size * 1.13));
    };
    drawText(c.name.toLocaleUpperCase('pt-BR'), 18, 120.75, 464, 31.5, 28, 700, '#daeaff');
    drawText(c.job + (c.unit ? ' | ' + c.unit : ''), 18, 154, 464, 41.3, 24);
    ctx.font = '700 15.25px Arial, sans-serif'; ctx.fillText('E-MAIL', 18, 207.2);
    drawText(c.email, 18, 230, 464, 35.7, 24, 400, '#daeaff');
    ctx.fillStyle = '#ffffff'; ctx.font = '700 15.25px Arial, sans-serif'; ctx.fillText('TELEFONE/WHATSAPP', 18, 281.75);
    drawText(C.displayPhone(c.phone), 18, 304.55, 464, 35.7, 24, 400, '#daeaff');
    ctx.drawImage(motif, 221, 393.4, 57, 57 * motif.height / motif.width);
    const qx = 166.5, qy = 484.4, qs = 169.5, padding = qs * .035;
    ctx.save(); ctx.beginPath(); ctx.roundRect(qx, qy, qs, qs, qs * .09); ctx.clip();
    ctx.fillStyle = '#fff'; ctx.fillRect(qx, qy, qs, qs);
    ctx.imageSmoothingEnabled = false; ctx.drawImage(qr, qx + padding, qy + padding, qs - 2 * padding, qs - 2 * padding); ctx.restore(); ctx.restore();
    return canvas;
  }
  async function exportPDF() {
    const data = ready(); if (!data) return;
    const button = $('pdf'); button.disabled = true; feedback('Preparando seu PDF…');
    try {
      const canvas = await cardCanvas(data), pdf = await PDFLib.PDFDocument.create();
      const image = await pdf.embedPng(canvas.toDataURL('image/png'));
      const width = 90 / 25.4 * 72, height = 126 / 25.4 * 72;
      pdf.addPage([width, height]).drawImage(image, { x: 0, y: 0, width, height });
      pdf.setTitle('Cartão de visita · ' + data.name); pdf.setAuthor('FHE POUPEX'); pdf.setSubject('Contato profissional');
      download(new Blob([await pdf.save()], { type: 'application/pdf' }), C.filename(data.name) + '.pdf');
      feedback('PDF gerado. Confira o arquivo nos downloads.');
    } catch (error) { feedback(error instanceof Error ? error.message : 'Não foi possível gerar o PDF. Tente novamente.', true); }
    finally { button.disabled = false; }
  }
  async function wallet(kind) {
    if (!walletConfig[kind]) {
      $('wallet-dialog-title').textContent = kind === 'apple' ? 'Apple Wallet em preparação' : 'Google Wallet em preparação';
      $('wallet-dialog-copy').textContent = 'A emissão nesta carteira depende da configuração da conta institucional pela equipe responsável.';
      $('wallet-dialog').showModal(); return;
    }
    const contact = ready(); if (!contact) return;
    const button = $(kind); button.disabled = true; feedback('Preparando seu cartão…');
    try {
      const response = await fetch('/api/wallet/' + kind, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(contact) });
      if (!response.ok) { const error = await response.json(); throw new Error(error.error || 'Não foi possível emitir o cartão.'); }
      if (kind === 'apple') download(await response.blob(), C.filename(contact.name) + '.pkpass');
      else { const result = await response.json(); if (!result.url.startsWith('https://pay.google.com/gp/v/save/')) throw new Error('O endereço da carteira não foi reconhecido.'); window.location.assign(result.url); }
      feedback(kind === 'apple' ? 'Cartão gerado. Abra o arquivo no iPhone para adicioná-lo à Apple Wallet.' : 'Abrindo o Google Wallet…');
    } catch (error) { feedback(error.message || 'Não foi possível conectar à carteira. Tente novamente.', true); }
    finally { button.disabled = false; }
  }
  async function config() {
    if (!document.documentElement.hasAttribute('data-standalone')) {
      try { const response = await fetch('/api/config', { cache: 'no-store' }); if (response.ok) walletConfig = await response.json(); } catch { /* Exportações locais continuam disponíveis. */ }
    }
    for (const kind of ['apple', 'google']) $(kind + '-status').textContent = walletConfig[kind] ? 'Adicionar cartão' : 'Em preparação';
    $('wallet-note').textContent = walletConfig.apple && walletConfig.google ? 'Escolha a carteira que você usa no celular.' : 'As opções em preparação aguardam a configuração institucional.';
  }
  $('contact-form').addEventListener('submit', e => { e.preventDefault(); ready(); });
  keys.forEach(key => {
    $(key).addEventListener('input', () => { feedback(''); clearTimeout(timer); timer = setTimeout(update, 160); });
    $(key).addEventListener('blur', () => { touched.add(key); update(); });
  });
  $('example').addEventListener('click', () => { const example = { name: 'Marina Costa', job: 'Analista de Comunicação', unit: 'CECOM', email: 'marina.costa@example.org', phone: '(61) 99999-0000' }; for (const key of keys) $(key).value = example[key]; touched.clear(); update(); feedback('Exemplo fictício preenchido. Substitua pelos seus dados profissionais.'); });
  $('clear').addEventListener('click', () => { $('contact-form').reset(); touched.clear(); update(); feedback('Dados removidos.'); $('name').focus(); });
  $('pdf').addEventListener('click', exportPDF);
  $('vcf').addEventListener('click', () => { const data = ready(); if (data) { download(new Blob([C.vcard(data)], { type: 'text/vcard;charset=utf-8' }), C.filename(data.name) + '.vcf'); feedback('Contato gerado. Abra o arquivo para salvá-lo na agenda.'); } });
  $('apple').addEventListener('click', () => wallet('apple')); $('google').addEventListener('click', () => wallet('google'));
  window.addEventListener('resize', fitPreview);
  update(); config();
})();
